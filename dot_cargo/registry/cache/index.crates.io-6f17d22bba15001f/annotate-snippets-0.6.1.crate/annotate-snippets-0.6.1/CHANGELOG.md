# Changelog
 
## Unreleased
 
  - …

## annotate-snippets 0.6.1 (July 23, 2019)

  - Fix too many anonymized line numbers (#5)
 
## annotate-snippets 0.6.0 (June 26, 2019)
 
  - Add an option to anonymize line numbers (#3)
  - Transition the crate to rust-lang org.
  - Update the syntax to Rust 2018 idioms. (#4)
